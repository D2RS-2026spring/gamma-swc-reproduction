# 加载包
library(tidyverse)
library(ggplot2)

# 加载数据
clean_data <- read_csv("data/processed/clean_swc_data.csv")

# 1. 校准模型
cal_model <- lm(swc_gravimetric ~ k40_counts, data = clean_data)
print(summary(cal_model))

# 2. 绘制时间序列图
p1 <- ggplot(clean_data, aes(x = date, y = swc_gravimetric, color = crop_type)) +
  geom_point() +
  geom_line() +
  labs(title = "土壤含水量时间序列", x = "日期", y = "土壤含水量(g/g)") +
  theme_minimal()

# 保存图表
ggsave("results/figures/swc_timeseries.png", p1, width = 10, height = 6)
print("分析完成，图表已保存！")