# 生成论文数据的模拟版本，用于流程复现
library(tidyverse)
library(lubridate)

# 1. 设置随机种子（保证结果可复现）
set.seed(12345)

# 2. 生成模拟数据（匹配论文数据结构）
dates <- seq(ymd("2021-01-01"), ymd("2023-12-31"), by = "day")
n <- length(dates)

simulated_data <- tibble(
  date = dates,
  k40_counts = sample(5000:8000, n, replace = TRUE),  # 40K计数率（论文范围）
  swc_gravimetric = round(runif(n, 0.1, 0.35), 3),     # 土壤含水量（论文范围）
  crop_type = sample(c("玉米", "大豆"), n, replace = TRUE)  # 作物类型
)

# 3. 保存模拟数据到raw文件夹（模拟原始数据）
write_csv(simulated_data, "data/raw/simulated_becker_2024_data.csv")

# 4. 提示完成
cat("模拟数据生成完成！文件保存至：data/raw/simulated_becker_2024_data.csv\n")
cat("数据量：", nrow(simulated_data), "行\n")
cat("字段说明：\n")
cat("- date：采样日期\n")
cat("- k40_counts：40K放射性计数率\n")
cat("- swc_gravimetric：重量法土壤含水量（g/g）\n")
cat("- crop_type：作物类型\n")