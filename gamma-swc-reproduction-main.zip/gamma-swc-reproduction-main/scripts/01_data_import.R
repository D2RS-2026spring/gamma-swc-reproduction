# 加载包
library(tidyverse)
library(lubridate)

# 1. 导入原始数据（后续把数据放到data/raw/后，把路径改对）
raw_data <- read_csv("data/raw/simulated_becker_2024_data.csv")

# 2. 数据清洗
clean_data <- raw_data %>%
  mutate(date = ymd(date)) %>%
  select(date, k40_counts, swc_gravimetric, crop_type) %>%
  drop_na()

# 3. 保存清洗后的数据
write_csv(clean_data, "data/processed/clean_swc_data.csv")

print("数据清洗完成，已保存到data/processed/")