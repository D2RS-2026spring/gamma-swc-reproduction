# 脚本1：导入论文真实原始数据并清洗（基于CalibrationDataK40和CombinedTimeSeries）
library(tidyverse)
library(lubridate)
library(ggplot2)

# ---------------------- 1. 导入真实数据（data/raw里的6个原始文件） ----------------------
# 40K校准数据（论文核心校准数据集）
cal_k40 <- read_csv("data/raw/CalibrationDataK40.csv")
# 时间序列数据（论文图2、图3的数据源）
time_series <- read_csv("data/raw/CombinedTimeSeries.csv")
# 植被校准数据（补充植被对测量的影响分析）
cal_veg <- read_csv("data/raw/CalibrationDataVeg.csv")
# 算术平均值数据
arithmetic_avg <- read_csv("data/raw/ArithmeticAvg.csv")
# 孔隙加权平均数据
pore_avg <- read_csv("data/raw/V_Wt_AvgPore.csv")
# 土壤有机碳+晶格数据
soc_lattice <- read_csv("data/raw/SOCandLatticeValues.csv")

# ---------------------- 2. 数据探索（论文方法部分对应步骤） ----------------------
# 查看校准数据基本结构（确保与论文描述一致）
cat("=== CalibrationDataK40 数据结构 ===\n")
print(str(cal_k40))
cat("\n=== 缺失值统计 ===\n")
print(summary(cal_k40))

# ---------------------- 3. 数据清洗（按论文方法处理） ----------------------
# 3.1 清洗40K校准数据：去除k40_counts异常值（<3000次/分钟）+ 缺失值
cal_k40_clean <- cal_k40 %>%
  mutate(date = ymd(date)) %>%  # 统一日期格式
  filter(k40_counts > 3000) %>% # 排除仪器故障的低计数（论文方法2.3节提及）
  drop_na(swc_gravimetric, k40_counts) %>% # 去除核心变量缺失值
  select(date, k40_counts, swc_gravimetric, depth_cm, crop_type) # 保留论文关键变量

# 3.2 清洗时间序列数据：按作物生长季筛选（玉米：5-9月；大豆：6-10月）
time_series_clean <- time_series %>%
  mutate(
    date = ymd(date),
    month = month(date)
  ) %>%
  filter(
    (crop_type == "Corn" & month %in% 5:9) | 
    (crop_type == "Soybean" & month %in% 6:10)
  ) %>%
  drop_na(swc_gravimetric, k40_counts)

# ---------------------- 4. 保存清洗后的数据到data/processed ----------------------
# 先检查data/processed文件夹是否存在，不存在则创建（避免报错）
if (!dir.exists("data/processed")) {
  dir.create("data/processed", recursive = TRUE)
}

write_csv(cal_k40_clean, "data/processed/cal_k40_clean.csv")
write_csv(time_series_clean, "data/processed/time_series_clean.csv")

# 输出清洗结果提示
cat("\n✅ 真实数据清洗完成！\n")
cat("已保存文件：\n")
cat("- data/processed/cal_k40_clean.csv（40K校准数据，", nrow(cal_k40_clean), "行）\n")
cat("- data/processed/time_series_clean.csv（时间序列数据，", nrow(time_series_clean), "行）\n")